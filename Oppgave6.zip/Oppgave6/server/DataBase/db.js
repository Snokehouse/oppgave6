export default new Map([
  [
    '0',
    {
      title: 'Title 1',
      content: "Lorem Ipsum"
    },
  ],
  [
    '1',
    {
      title: 'Title 2',
      content: 'Lorem Ipsum 2',
    },
  ],
]);
